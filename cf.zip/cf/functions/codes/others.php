<?php

/**
 * Get standard request headers for a host.
 * The Cookie header is intentionally omitted – Run() handles cookies via per‑account jar files.
 *
 * @param string $host
 * @return array
 */
/**
 * Retrieve Cloudflare cookie and user agent for a given host.
 * If a proxy IP is provided, looks for a proxy-specific cookie file first,
 * falling back to the generic cf_cookie.txt.
 *
 * @param string $host  The target domain.
 * @param string|null $proxy  Optional proxy IP/hostname.
 * @return array|null  ['cf_cookie' => string, 'user_agent' => string] or null if folder missing.
 */

/**
 * Build request headers using the appropriate CF cookie and user agent.
 *
 * @param string $host  Target domain.
 * @param string|null $proxy  Optional proxy IP/hostname.
 * @return array
 */
function getRequestHeaders($host, $proxy = null, $email = null) {
    // Parse proxy to extract host and port for cookie file key
    [$proxyHost, $proxyPort, $fullProxy] = parseProxy($proxy);
    $proxyKey = empty($proxyHost) ? '' : $proxyHost . '-' . $proxyPort;
    
    // Use proxyKey (host-port or empty) to load the correct cookie file
    $cookies = getCfCookieAndUserAgent($host, $proxyKey);

    $userAgent = saveData(APP_HOST, 'UserAgent');
    if (!empty($cookies['user_agent'])) {
        $userAgent = $cookies['user_agent'];
    }

    $cookieString = '';
    if (!empty($cookies['cf_cookie'])) {
        // Convert "cf_clearance value" to "cf_clearance=value"
        $cookieString = str_replace(" ", "=", $cookies['cf_cookie']) . ";";
    }

    if (empty($cookieString)) {
        // Fallback: use original full proxy string (including auth if any)
        $cookieString = get_cookies($host, $proxy, $email);
    }

    $header = [
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "User-Agent: " . $userAgent,
    ];
    
    if ($cookieString) {
        $header[] = "cookie: " . $cookieString;
    }
    
    return $header;
}

/**
 * Get form submission headers.
 * Cookie header is omitted if no cookie is available (fallback to per‑account jar).
 *
 * @param string $host
 * @param string $html  Page HTML (used to detect XHR requirements)
 * @param string|null $proxy  Optional proxy IP/hostname.
 * @return array
 */
function getFormHeaders($host, $html, $proxy = null, $email = null) {

    [$proxyHost, $proxyPort, $fullProxy] = parseProxy($proxy);
    $proxyKey = empty($proxyHost) ? '' : $proxyHost . '-' . $proxyPort;
    
    // Only call once
    $cookies = getCfCookieAndUserAgent($host, $proxyKey);     

    $userAgent = saveData(APP_HOST, 'UserAgent');
    if (!empty($cookies['user_agent'])) {
        $userAgent = $cookies['user_agent'];
    }

    $cookieString = '';
    if (!empty($cookies['cf_cookie'])) {
        $cookieString = str_replace(" ", "=", $cookies['cf_cookie']) . ";";
    }

    if (empty($cookieString)) {
        // Use $fullProxy (original proxy string) if your get_cookies expects that format
        $cookieString = get_cookies($host, $fullProxy, $email);
    }

    $headers = [
        "User-Agent: " . $userAgent,
        "Referer: https://$host/",
        "Origin: https://$host",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "cookie: " . $cookieString
    ];

    if (str_contains($html, 'XMLHttpRequest')) {
        $headers[] = "x-requested-with: XMLHttpRequest";
    }

    if ($host == "coinszon.com" || $host == "claimlitoshi.top") {
        $headers[] = "x-requested-with: XMLHttpRequest";

        // Use FULL proxy here
        $headers[] = "x-server-hash: " . get_hash("https://$host/", $html, $email, $fullProxy);
    }

    return $headers;
}

function parseProxy($proxy) {
    if (empty($proxy)) return [null, null, null]; // host, port, fullProxy

    $fullProxy = $proxy;
    $host = null;
    $port = null;

    // Extract host and port from "user:pass@host:port" or "host:port" or just "host"
    if (strpos($proxy, '@') !== false) {
        $parts = explode('@', $proxy, 2);
        $hostPort = $parts[1];
    } else {
        $hostPort = $proxy;
    }

    $hostPortParts = explode(':', $hostPort);
    $host = $hostPortParts[0];
    $port = isset($hostPortParts[1]) ? $hostPortParts[1] : null;

    return [$host, $port, $fullProxy];
}

/**
 * Check if the claim count is zero based on HTML patterns.
 *
 * @param string $html
 * @return bool
 */
function isClaimZero($html) {
    // Format 1 & 2 (Claim Left before h3)
    if (preg_match('/<p[^>]*>\s*Claim\s*Left\s*<\/p>\s*<h3[^>]*>(\d+)\/\d+<\/h3>/i', $html, $matches)) {
        return ((int)$matches[1] === 0);
    }

    // Format 3 (h3 before Claim Left)
    if (preg_match('/<h3[^>]*>(\d+)\/\d+<\/h3>\s*<p[^>]*>\s*Claim\s*Left\s*<\/p>/i', $html, $matches)) {
        return ((int)$matches[1] === 0);
    }

    return false;
}

/**
 * Log a message with timestamp, proxy IP, action, and colored message.
 *
 * @param string $host
 * @param string $message
 * @param string $action
 * @param string|null $proxy
 * @param string $color
 */
function logMessage($host, $message, $action, $proxy, $color = GREEN) {
    // Extract IP from proxy if provided
    $proxyIp = '';
    if (!empty($proxy)) {
        if (!preg_match('#^https?://#i', $proxy)) {
            $proxyWithScheme = "http://{$proxy}";
        } else {
            $proxyWithScheme = $proxy;
        }
        $parts = parse_url($proxyWithScheme);
        if (!empty($parts['host'])) {
            $proxyIp = explode(':', $parts['host'])[0];
        }
    }

    $dateFormatted = date("H:i:s");

    // Build colored log line
    $log = PURPLE . "[" . WHITE . $dateFormatted . PURPLE . "]";
    if (!empty($proxyIp)) {
        $log .= PURPLE . "[" . WHITE . $proxyIp . PURPLE . "]";
    }
    $log .= PURPLE . "[" . WHITE . $action . PURPLE . "] " . $color . $message . WHITE;

    echo $log . "\n";

    // Save plain text version
    $plainLog = "[" . $dateFormatted . "]";
    if (!empty($proxyIp)) {
        $plainLog .= "[" . $proxyIp . "]";
    }
    $plainLog .= "[" . $action . "] " . $message;
   # save_as_text($plainLog);
}

/**
 * Perform a safe GET request with Cloudflare/firewall handling.
 *
 * @param string $url
 * @param string $host
 * @param string $email  Account email (used as name for cookie jar)
 * @param string|null $proxy
 * @return array
 */
function safeRequest($url, $host, $email = null, $proxy = null) {
    // Pass full $proxy to getRequestHeaders – it will parse internally
    $response = Run($url, getRequestHeaders($host, $proxy, $email), null, "data", $proxy, 2, $email);
    
    $html = $response['body'] ?? '';

    // Cloudflare challenge
    if (preg_match('/Just a moment.../', $html)) {
        $response = check_cloudflare($url, $host, $email, $proxy);
    }

    // Firewall redirect
    if (str_contains($response['info']['redirect_url'] ?? '', 'firewall')) {
        firewall($response['info']['redirect_url'], $host, $email, $proxy);
        $response = Run($url, getRequestHeaders($host, $proxy, $email), null, "data", $proxy, 2, $email);
    }

    return $response;
}

/**
 * Perform a safe POST request with Cloudflare handling.
 */
function safeRequestpost($url, $host, $post, $html, $email, $proxy = null) {
    // Pass full $proxy to getFormHeaders – it will parse internally
    $headers = array_merge(getFormHeaders($host, $html, $proxy, $email), ["x-requested-with: XMLHttpRequest"]);
    $response = Run($url, $headers, $post, "data", $proxy, 2, $email);
    $html = $response['body'] ?? '';

    if (preg_match('/Just a moment.../', $html)) {
        $response = check_cloudflare_post($url, $host, $post, $html, $email, $proxy);
    }

    return $response;
}

/**
 * Determine if the response indicates a shortlink is required.
 *
 * @param string $text
 * @param bool $e  Extended mode
 * @return bool
 */
function requiresShortlink($text, $e = null) {
    $msg = strtolower($text);

    $phrases = [
        'shortlink to continue',
        'to continue complete',
        'unlock the faucet',
        'shortlink to claim faucet',
        'you need to do at least',
        'before claiming again',
        'You need to claim at least'
    ];

    if ($e) {
        $phrases = array_merge($phrases, [
            'must complete shortlink',
            'must be completed',
            'complete shortlink',
            'shortlink must',
            'must complete shortlink',
            'must be completed',
            'complete shortlink',
            'shortlink required',
            'shortlinks required',
            'after every',
            'No Faucet EXP left! Complete PTC or shortlinks to keep claiming faucets.'
        ]);
    }

    foreach ($phrases as $p) {
        if (str_contains($msg, $p)) {
            return true;
        }
    }

    return false;
}

/**
 * Handle firewall page – extract and submit form.
 *
 * @param string $url
 * @param string $host
 * @param string $email
 * @param string|null $proxy
 */
function firewall($url, $host, $email, $proxy = null) {
    $response = Run($url, getRequestHeaders($host, $proxy, $email), null, "data", $proxy, 2, $email);
    $html = $response['body'];

    $formData = scrapePage($html);
    
    if (empty($formData)) {
        return;
    }

    $formPayload = builder(
        $formData,
        $email,
         null,
        $proxy,
        $html,
        $url,
    );
     
    if (empty($formPayload)) {
        return;
    }

   $E = Run(
        $formData['action'] ?? $url,
        getFormHeaders($host, $html, $proxy, $email),
        $formPayload,
        "data",
        $proxy,
        2,
        $email
    );
    
}

/**
 * Handle Cloudflare challenge for GET requests.
 */
function check_cloudflare($url, $host, $email, $proxy = null) {
    $response = Run($url . "/", getRequestHeaders($host, $proxy, $email), null, "data", $proxy, 2, $email);
    $html = $response['body'];

    if ($response['info']['http_code'] == 301 || $response['info']['http_code'] == 404) {
        $response = Run($url, getRequestHeaders($host, $proxy, $email), null, "data", $proxy, 2, $email);
        $html = $response['body'];
    }

    if (preg_match('/Just a moment.../', $html)) {
        $cfResult = bypassCloudFlare($url, $proxy);
        $response = Run($url, getRequestHeaders($host, $proxy, $email), null, "data", $proxy, 2, $email);
    }

    return $response;
}


/**
 * Handle Cloudflare challenge for POST requests.
 */
function check_cloudflare_post($url, $host, $post, $html, $email, $proxy = null) {
    $headers = array_merge(getFormHeaders($host, $html, $proxy, $email), ["x-requested-with: XMLHttpRequest"]);
    $response = Run($url . "/", $headers, $post, "data", $proxy, 2, $email);
    $html = $response['body'];

    if ($response['info']['http_code'] == 301 || $response['info']['http_code'] == 404 || $response['info']['http_code'] == 403) {
        $response = Run($url, $headers, $post, "data", $proxy, 2, $email);
        $html = $response['body'];
    }

    if (preg_match('/Just a moment.../', $html)) {
        $cfResult = bypassCloudFlare($url, $proxy);
        if (!$cfResult || !$cfResult['success']) {
            return $response;
        }
        $headers = array_merge(getFormHeaders($host, $html, $proxy, $email), ["x-requested-with: XMLHttpRequest"]);
        $response = Run($url, $headers, $post, "data", $proxy, 2, $email);
    }

    return $response;
}


/**
 * Parse reward amount from JSON response.
 *
 * @param string $body
 * @return string|null
 */
function parseReward($body) {
    $data = json_decode($body, true);

    if (json_last_error() === JSON_ERROR_NONE && is_array($data)) {
        if (!empty($data['msg'])) {
            return strip_tags($data['msg']);
        } elseif (!empty($data['message'])) {
            return strip_tags($data['message']);
        }
    }

    return null;
}

/**
 * Save plain text to log file.
 *
 * @param string $text
 */
function save_as_text($data) {
    $file = 'logs.json';
    $dir = dirname($file);
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true); // create directory if missing
    }

    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false) {
        error_log('JSON encoding failed: ' . json_last_error_msg());
        return false;
    }
    return file_put_contents($file, $json . PHP_EOL, FILE_APPEND | LOCK_EX) !== false;
}


function maskEmail($email) {
    $parts = explode('@', $email);
    if (count($parts) !== 2) return $email;

    $name = $parts[0];

    if (strlen($name) <= 7) {
        return substr($name, 0, 2) . '...' . substr($name, -2) . '@' . $parts[1];
    }

    return substr($name, 0, 4) . '.....' . substr($name, -3) . '@' . $parts[1];
}

if (!defined('BASE_DIR')) {
    define('BASE_DIR', dirname(__DIR__));
}

define('CONFIG_DIR', BASE_DIR . '/configs/');
define('SESSION_DIR', BASE_DIR . '/sessions/');

// Ensure directories exist
if (!is_dir(CONFIG_DIR)) mkdir(CONFIG_DIR, 0777, true);
if (!is_dir(SESSION_DIR)) mkdir(SESSION_DIR, 0777, true);

/**
 * Load host configuration from JSON file.
 *
 * @param string $host Hostname (e.g., "claimcrypto.cc")
 * @return array Configuration array with defaults
 */
function loadHostConfig($host) {
    $file = CONFIG_DIR . $host . '.json';
    $default = [
        'faucet_urls'     => [],
        'shortlink_urls'  => [],
        'last_extracted'  => 0,
        'disabled_pairs'  => [],  // coin identifiers like "pepe", "ltc"
        'extract_interval' => 10800, // 3 hours in seconds
    ];
    
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        return array_merge($default, $data);
    }
    return $default;
}

/**
 * Save host configuration to JSON file.
 */
function saveHostConfig($host, $config) {
    $file = CONFIG_DIR . $host . '.json';
    file_put_contents($file, json_encode($config, JSON_PRETTY_PRINT));
}

/**
 * Extract all faucet and shortlink URLs from the page and update config.
 * Returns the updated config.
 */
function updateHostLinks($host) {
    $config = loadHostConfig($host);
    
    // Fetch the main page to extract links
    $response = safeRequest("https://$host/dashboard", $host, '', null);
    $html = $response['body'] ?? '';
    
    if (empty($html)) return $config;
    
    // Use the unified extractor (defined later)
    $links = extractAllLinks($html, "https://$host");
    
    $config['faucet_urls']    = $links['faucet'] ?? [];
    $config['shortlink_urls'] = $links['shortlinks'] ?? [];
    $config['last_extracted'] = time();
    
    // Clear disabled pairs that no longer exist? Or keep them.
    // We'll keep them; they will be re-enabled if links are re-extracted and we reset disabled list.
    // Optionally reset disabled_pairs on refresh:
    // $config['disabled_pairs'] = [];
    
    saveHostConfig($host, $config);
    return $config;
}

/**
 * Check if links should be refreshed (older than extract_interval).
 */
function shouldRefreshLinks($host) {
    $config = loadHostConfig($host);
    $interval = $config['extract_interval'] ?? 10800;
    return (time() - $config['last_extracted']) > $interval;
}

/**
 * Disable a coin pair (both faucet and shortlink) due to insufficient funds.
 * @param string $host
 * @param string $coin Coin identifier extracted from URL (e.g., "pepe")
 */
function disableCoinPair($host, $coin) {
    $config = loadHostConfig($host);
    if (!in_array($coin, $config['disabled_pairs'])) {
        $config['disabled_pairs'][] = $coin;
        saveHostConfig($host, $config);
    }
}

/**
 * Check if a coin pair is disabled.
 */
function isCoinPairDisabled($host, $coin) {
    $config = loadHostConfig($host);
    return in_array($coin, $config['disabled_pairs']);
}

/**
 * Get active faucet URLs (excluding disabled pairs).
 */
function getActiveFaucetUrls($host) {
    $config = loadHostConfig($host);
    $active = [];
    foreach ($config['faucet_urls'] as $url) {
        $coin = extractCoinFromUrl($url);
        if (!isCoinPairDisabled($host, $coin)) {
            $active[] = $url;
        }
    }
    return $active;
}

/**
 * Get active shortlink URLs (excluding disabled pairs).
 */
function getActiveShortlinkUrls($host) {
    $config = loadHostConfig($host);
    $active = [];
    foreach ($config['shortlink_urls'] as $url) {
        $coin = extractCoinFromUrl($url);
        if (!isCoinPairDisabled($host, $coin)) {
            $active[] = $url;
        }
    }
    return $active;
}

/**
 * Extract coin identifier from a faucet or shortlink URL.
 * e.g., "https://claimcrypto.cc/faucet/pepe" -> "pepe"
 *       "https://claimcrypto.cc/links/pepe"  -> "pepe"
 */
function extractCoinFromUrl($url) {
    $path = parse_url($url, PHP_URL_PATH);
    $parts = explode('/', trim($path, '/'));
    return end($parts);
}

// ======================== ACCOUNT SESSION MANAGEMENT ========================

/**
 * Load session data for a specific account (email) on a host.
 */
function loadAccountSession($email, $host) {
    $safeEmail = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $email);
    $file = SESSION_DIR . $host . '_' . $safeEmail . '.json';
    $default = [
        'logged_in'       => false,
        'cookies'         => [],
        'last_check'      => 0,
        'check_interval'  => 900, // 15 minutes in seconds
    ];
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        return array_merge($default, $data);
    }
    return $default;
}

/**
 * Save session data for an account.
 */
function saveAccountSession($email, $host, $session) {
    $safeEmail = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $email);
    $file = SESSION_DIR . $host . '_' . $safeEmail . '.json';
    file_put_contents($file, json_encode($session, JSON_PRETTY_PRINT));
}

/**
 * Check if the account session is still considered valid.
 */
function isSessionValid($email, $host) {
    $session = loadAccountSession($email, $host);
    if (!$session['logged_in']) return false;
    $interval = $session['check_interval'] ?? 900;
    return (time() - $session['last_check']) < $interval;
}

/**
 * Mark account as logged in and update last check time.
 */
function markSessionValid($email, $host, $cookies = []) {
    $session = loadAccountSession($email, $host);
    $session['logged_in'] = true;
    $session['last_check'] = time();
    if (!empty($cookies)) {
        $session['cookies'] = $cookies;
    }
    saveAccountSession($email, $host, $session);
}
