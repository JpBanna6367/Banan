<?php
error_reporting(0);
$base = __DIR__;
include_once(__DIR__ . "/function/function.php");
include_once(__DIR__ . "/captcha/captcha-helper.php");
include_once(__DIR__ . "/parser/payload.php");
include_once(__DIR__ . "/codes/link.php");
include_once(__DIR__ . "/codes/others.php");
include_once(__DIR__ . "/session/session.php");
include_once(__DIR__ . "/offerwall/bitcotask/bitco.php");
