<?php

class PhpObf {

  private array $names = array();

  private string $nono = "\x1b[H\x1b[2J\x1b[3J";

  private string $enctype = '';

  private string $dectype = '';

  private function split_code($code, $bagi, $enc=false)

  {

    if($enc)

      $code = $this->encc($code, false);

    $data = str_split($code, round(strlen($code) / $bagi- strlen($code) % 2));

    if((strlen($code) % 2) !== 0 or count($data) > $bagi)

      $data[count($data) - 2] .= array_pop($data);

    return $data;

  }

  private function uhex($variabel=false)

  {

    while(true){

      $name = '';

      for($i=0;$i<rand(2,7);$i++)

        $name .= chr(rand(140,254));

      if(mb_check_encoding($name, 'ASCII'))

        continue;

      if(!in_array($name, $this->names)){

        array_push($this->names, $name);

        return ($variabel ? '$' : '') . $name;

      }

    }

  }

  private function strguard($str)

  {

    $data = '';

    foreach(str_split($str) as $x)

      $data .= sprintf('\\x%x', ord($x));

    return sprintf('"%s"', $data);

  }

  private function encc($code, $repr=true)

  {

    $enc = $this->enctype;

    $res = $enc($code);

    return ($repr ? var_export($res, true) : $res);

  }

  private function varcrt($value)

  {

    $vname = $this->uhex(true);

    return array(

      $vname,

      sprintf('%s=%s;', $vname, $value)

    );

  }

  private function mkeval($code, $dec_name, $end=true)

  {

    return sprintf('eval(%s(%s))'.($end ? ';' : '^'),

      $dec_name,

      $this->encc(sprintf('?>%s /*%s*/', $this->format($code), $this->nono))

    );

  }

  private function format($code){

    $code = trim($code);

    if(!str_starts_with(trim($code), '<?php'))

      $code = sprintf('<?php %s',$code);

    return $code;

  }

  public function __construct($enc=2)

  {

    $encs = $enc === 2 ? rand(0, 1) : $enc;

    if(!$encs){

      $this->dectype = 'gzuncompress';

      $this->enctype = 'gzcompress';

    } else {

      $this->dectype = 'gzdecode';

      $this->enctype = 'gzencode';

    }

  }

  public function olah($code)

  {

    $result = $this->format(' /*
    ××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××
                 https://t.me/Stilbesilent                           _____ __  _ ________      _____ _ ____           __          / ___// /_(_) / / __ )___ / ___/(_) / /__  ____  / /_         \__ \/ __/ / / / __  / _ \__ \/ / / / _ \/ __ \/ __/         ___/ / /_/ / / / /_/ /  __/__/ / / / /  __/ / / / /_         /____/\__/_/_/_/_____/\___/____/_/_/_/\___/_/ /_/\__/                                                                      DONOT EDIT ANYTHING                CRE@TOR  :  SHH!        ×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××× 
    */');

    $code = '?>'.$this->format($code);

    $codes = $this->split_code($code, 3, true);

    $keys = array();

    $index = array();

    $data = array();

    foreach($codes as $i => $dt){

      $key = rand(60,80);

      $index[$i] = array();

      foreach(str_split($dt) as $x){

        $ctm = bin2hex(ord($x) + $key);

        array_push($index[$i], $ctm);

        array_push($data, $ctm);

      }

      array_push($keys, bin2hex($key));

    }

    $data = array_unique($data);

    if(rsort($data))

      foreach($index as $i => $ix){

        $ix_new = array();

        foreach($ix as $x)

          array_push($ix_new, array_search($x, $data));

        $forex=join(str_shuffle(join(range(':','z')))[0], $ix_new);

        $index[$i] = $this->encc($forex);

      }

    $data = $this->encc(json_encode($data), false);

    list(

      $index1,

      $index2,

      $index3

    ) = $index;

    list(

      $index_1_pos,

      $varb1

    ) = $this->varcrt($index1);

    list(

      $index_2_pos,

      $varb2

    ) = $this->varcrt($index2);

    list(

      $index_3_pos,

      $varb3

    ) = $this->varcrt($index3);

    $funcs = array(

      $this->dectype,

      'hex2bin',

      'substr',

      'chr',

      'file_get_contents',

      'file_exists',

      'preg_match',

      'rand',

      'strlen',

      'json_decode',

      'unlink',

      'error_reporting',

      'preg_split',

      'empty',

      'trim',

      'strrev'

    );

    list(

      $var_file_name,

      $varb_file_nm

    ) = $this->varcrt('__FILE__');

    $encc1 = $this->uhex();

    $result .= sprintf('define("%s", %s);', $encc1,$this->strguard($this->dectype));

    $addcok = rand(1,count($funcs)-1);

    $func1 = array();

    foreach($funcs as $i => $f){

      list(

        $var_name,

        $varb

      ) = $this->varcrt(sprintf('(%s)(%s)', $encc1, $this->encc($f)));

      $func1[$f] = $var_name;

      if($addcok === $i){

        $result .= $varb_file_nm;

        $result .= sprintf('/*%s%s%s*/', strrev($data), $this->uhex() ,$this->nono);

      }

      $result .= $varb;

    }

    $vartod = '';

    $func2 = array();

    foreach($funcs as $f){

      list(

        $var_name,

        $varb

      ) = $this->varcrt(sprintf('%s(%s)', $func1[$this->dectype], $this->encc($f)));

      $func2[$f] = $var_name;

      $vartod .= $varb;

    }

    $vartod .= $varb3; // index3

    $vartod .= sprintf('%s=%s;',$func1['chr'],$func2['hex2bin']);

    list(

      $var_file,

      $varb

    ) = $this->varcrt(sprintf('%s(%s??"")?%s(%s):""', $func2['file_exists'], $var_file_name, $func2['file_get_contents'], $var_file_name));

    $vartod .= $varb;

    $result .= $this->mkeval($vartod, $func1[$this->dectype]);

    list(

      $var_key_2,

      $varb

    ) = $this->varcrt(sprintf('%s(%s(int)%s(%s))', $func1['chr'], $this->mkeval($varb3, $func2[$this->dectype], false), $func2[$this->dectype], $this->encc((string)$keys[1])));

    $result .= $varb;

    list(

      $var_key_3,

      $varb

    ) = $this->varcrt(sprintf('%s(%s0)', $func2['hex2bin'], $this->mkeval(

      sprintf('%s%s="";%s=function(%s,%s=%d)use(%s, %s){return %s(%s(%s)-%s);};return %d;',

        $varb1,

        $func1['hex2bin'],

        $func1['file_exists'],

        $func1['substr'],

        $func1['chr'],

        hex2bin($keys[0]),

        $func2['chr'],

        $func2['hex2bin'],

        $func2['chr'],

        $func2['hex2bin'],

        $func1['substr'],

        $func1['chr'],

        $keys[2]

     ), $func2[$this->dectype], false)));

    $result .= $varb;

    // decode

    $er_men_pos=rand(strlen($result)/4, strlen($result))-1;

    $er_men=$result[$er_men_pos];

    $inilah = $this->mkeval(sprintf('%s=[%s,%s,%s];foreach([%s,%s,%s] as %s=>%s){foreach(%s(%s(%s),%s(%s)) as %s){if(%s(%s)!==""){%s=(int)%s[(int)%s];%s.=(%s[(int)%s(%s)]===%s(%s)&%s===0x000?%s(%s):%s(%s,(int)%s[%s]));}}}',

        $func1['chr'],

        $func1['chr'],

        $var_key_2,

        $var_key_3,

        $index_1_pos,

        $index_2_pos,

        $index_3_pos,

        $func2['empty'],

        $func1['json_decode'],

        $func2['preg_split'],

        $func2[$this->dectype],

        $this->encc('/[^\d]+/'),

        $func2[$this->dectype],

        $func1['json_decode'],

        $func2['json_decode'],

        $func2['trim'],

        $func2['json_decode'],

        $func1['empty'],

        $func1['strlen'],

        $func2['json_decode'],

        $func1['hex2bin'],

        $var_file,

        $func2[$this->dectype],

        $this->encc((string)$er_men_pos),

        $func2[$this->dectype],

        $this->encc((string)$er_men),

        $func2['empty'],

        $func1['file_exists'], // var

        $func1['empty'],

        $func1['file_exists'],

        $func1['empty'],

        $func1['chr'],

        $func2['empty']

    ), $func2[$this->dectype]);

    $tencend=$this->uhex(true);

    $end=rand(10,20);

    $tambah=rand($end/2, $end-1);

    $evals = $this->mkeval(sprintf('eval(%s(%s));', $tencend, $func1['hex2bin']), $tencend);

    while(true){

      if($end===$tambah)

        $evals = $inilah.$evals;

      else

        $evals = $this->mkeval($evals, $tencend);

      if(!$end)

        break;

      $end--;

    }

    $result .= $this->mkeval(sprintf('%s%s(0x000);%s=%s(%s);%s=%s(1,4);if(%s(%s(%s),%s,%s))%s=%s(%s[0]);%s=%s(%s(%s(%s(%s,%d,(int)%s))));%s',

        $varb2,

        $func2['error_reporting'],

        $tencend,

        $func2[$this->dectype],

        $this->encc($this->dectype),

        $func1['rand'],

        $func2['rand'],

        $func2['preg_match'],

        $func2[$this->dectype],

        $this->encc('/[\s]+$/'),

        $var_file,

        $func1['preg_match'],

        $func1['rand'],

        $func2['strlen'],

        $func1['preg_match'],

        $func1['strlen'],

        $func2['json_decode'],

        $func2[$this->dectype],

        $func2['strrev'],

        $func2['substr'],

        $var_file,

        strpos($result, strrev($data)),

        $func1['rand'],

        $evals

    ), $func2[$this->dectype]);

    return trim($result).str_repeat(' ', strlen($data));

  }

};

$file=$argv[1] ?? "";

if(preg_match("~(^https?\:\/\/)~", $file, $x) || file_exists($file)){

  $out_file="obf-".(($x[0]??"")?(string)(rand(9999,999999)).".php":$file);

  $obf=new PhpObf();

  $result = $obf->olah(file_get_contents($file));

  file_put_contents($out_file, $result);

  echo $out_file;

}else{die("example: php ${argv[0]} [file/url]");

}
