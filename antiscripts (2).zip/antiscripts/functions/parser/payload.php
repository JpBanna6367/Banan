<?php

include_once("cooldown.php");
include_once("page-html.php");
include_once("reward-html.php");
include_once("extractor.php");
include_once("formdata.php");
include_once("payload_builder.php");




if (!defined('CAPTCHA_API_HOST')) {
    define('CAPTCHA_API_HOST', '');
}
if (!defined('CAPTCHA_API_KEY')) {
    define('CAPTCHA_API_KEY', '');
}

/**
 * Helper function to get page title from HTML
 */
function get_title($html) {
    return extractPageTitle($html);
}

/**
 * Helper function to extract captcha value (legacy compatibility)
 */
function Captcha_Value($html) {
    return extractCaptchaValue($html);
}

/**
 * Helper function to get form payload data (legacy compatibility)
 */
function get_payload($html) {
    return extractFormData($html);
}

/**
 * Helper function to fill payload with data (legacy compatibility)
 */
function fill_payload($payload, $base = null, $url = null, $r = null, $email = null, $pass = null, $host = null) {
    return prepareFormPayload($payload, $email, $pass, $url, $r, $host);
}

/**
 * Helper function to extract reward message (legacy compatibility)
 */
function reward_html($r) {
    return extractRewardMessage($r);
}