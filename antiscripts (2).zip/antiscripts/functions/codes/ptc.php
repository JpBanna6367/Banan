<?php

// ──────────────────────────────────────────────────────────────────

/**
 * Process PTC (Paid-to-Click) ads for a given account.
 */
function ptc(array $ptcUrls, string $host, array &$website, string $email, ?string $proxy = null): void {
    $count = 0;

    foreach ($ptcUrls as $ptcUrl) {

        // ── 1. Load PTC page ──────────────────────────────────────
        $html      = safeRequest($ptcUrl, $host, $email, $proxy)['body'] ?? '';
        $extracted = extractAdLinks($html, "https://$host/");

        // ── 2. Offerwall fallback ─────────────────────────────────
        if (empty($extracted['ptc'])) {
            if (!empty($extracted['offerwall'])) {
                foreach ($extracted['offerwall'] as $adLink) {
                    offerptc($adLink, $host, $email, $proxy);
                    if (++$count >= 3) return;
                }
            }
            continue;
        }

        // ── 3. Process each ad ────────────────────────────────────
        foreach ($extracted['ptc'] as $adLink) {
            processPtcAd($ptcUrl, $adLink, $host, $email, $proxy);
        }
    }
}

// ──────────────────────────────────────────────────────────────────

/**
 * Process a single PTC ad: solve captcha, wait timer, submit, log reward.
 */
function processPtcAd(string $ptcUrl, string $adLink, string $host, string $email, ?string $proxy = null): void {
    $response = safeRequest($adLink, $host, $email, $proxy);
    $html     = $response['body'] ?? '';
    $formData = extractFormData($html);

    if (empty($formData['captcha_name'])) return;

    $payload = prepareFormPayload(
        $formData, $email, null, $adLink, $html, $host,
        $GLOBALS['apihost'] ?? null,
        $GLOBALS['apikey']  ?? null,
        null, $proxy
    );
    if (empty($payload)) return;

    $timer = extractWaitTimer($html);
    if ($timer) countdown($timer, '');

    Run(
        $formData['action_url'] ?? $adLink,
        getFormHeaders($host, $html, parse_url("http://$proxy", PHP_URL_HOST), $email),
        $payload, 'data', $proxy, 2, $email
    );

    // ── Reload & log reward ───────────────────────────────────────
    $resultHtml = safeRequest($ptcUrl, $host, $email, $proxy)['body'] ?? '';
    $reward     = extractRewardMessage($resultHtml);
    $adUrl      = extractAdTarget($html);

    if ($reward) logMessage($host, "$reward | $adUrl", 'PTC', $proxy, GREEN);
}

// ──────────────────────────────────────────────────────────────────

/**
 * Extract the target ad URL from inline JS.
 */
function extractAdTarget(string $html): string {
    if (preg_match("/let\s+url\s*=\s*'([^']+)'/i", $html, $m)) return $m[1];
    return '';
}