<?php

function faucet(array &$faucetUrls, string $host, array &$website, string $email, ?string $proxy = null): array {
    $done = ['PTC' => true, 'SL' => true];

    foreach ($faucetUrls as $key => $url) {
        for ($attempt = 0; $attempt < 6; $attempt++) {

            if ($attempt === 5) return [];

            // ── 1. Load faucet page ───────────────────────────────
            $response = safeRequest($url, $host, $email, $proxy);
            $html     = $response['body'] ?? '';
            $msg      = strtolower(strip_tags($html));

            // Redirected away → shortlinks needed
            if (!empty($response['info']['redirect_url'])) return $done;

            // Faucet gives zero reward → skip it
            if (isClaimZero($html)) {
                removeFaucet($faucetUrls, $key);
                break;
            }

            // Shortlink wall
            if (requiresShortlink($html)) return $done;

            // Daily coin limit → skip this faucet
            if (str_contains($html, 'Daily claim limit for this coin')) {
                logMessage($host, 'Daily limit → skipping faucet', 'F', $proxy, RED);
                removeFaucet($faucetUrls, $key);
                break;
            }

            // Site-wide daily limit
            $limitCount = explode('</h3>', explode('<h3 class="mb-0 fs-5">', $html)[2] ?? '')[0] ?? '';
            if ($limitCount === '0') return $done;

            if (str_contains($msg, 'limit reached') ||
                str_contains($msg, 'max limit')      ||
                str_contains($msg, 'daily claim limit')) {
                return $done;
            }

            // ── 2. Build & submit claim form ──────────────────────
            $formData = extractFormData($html);
            $payload  = prepareFormPayload(
                $formData, $email, null, $url, $html, $host,
                $GLOBALS['apihost'] ?? null,
                $GLOBALS['apikey']  ?? null,
                get_cookies($host),
                $proxy
            );

            if (empty($payload)) {
                sleep(3);
                continue;
            }

            $verify = Run(
                $formData['action_url'] ?? $url,
                getFormHeaders($host, $html, parse_url("http://$proxy", PHP_URL_HOST), $email),
                $payload, 'data', $proxy, 2, $email
            );

            // ── 3. Parse reward ───────────────────────────────────
            $reward = parseReward($verify['body'] ?? '');

            // Reload for updated state / fallback reward message
            $html   = safeRequest($url, $host, $email, $proxy)['body'] ?? '';
            $reward = $reward ?: extractRewardMessage($html);

            // No funds → remove this faucet and move on
            if ($reward && str_contains($reward, 'does not have sufficient funds')) {
                logMessage($host, 'No funds → removing faucet', 'F', $proxy, RED);
                removeFaucet($faucetUrls, $key);
                break;
            }

            // Log reward
            if ($reward) logMessage($host, $reward, 'F', $proxy, GREEN);

            // Daily cap hit after claim
            if (str_contains((string)$reward, 'No Faucet EXP left') ||
                str_contains((string)$reward, 'You reached the maximum daily claims')) {
                return $done;
            }

            // Shortlink wall appeared after claim
            if (requiresShortlink($html, true)) return $done;

            // ── 4. Wait timer ─────────────────────────────────────
            $wait = extractWaitTimer($html);
            if ($wait) {
                if ($wait <= 30) countdown($wait, '');
                else             return ['Wait' => $wait];
            } else {
                sleep(5);
            }
        }
    }

    return [];
}

// ──────────────────────────────────────────────────────────────────

function removeFaucet(array &$faucetUrls, int|string $key): void {
    unset($faucetUrls[$key]);
    $faucetUrls = array_values($faucetUrls);
}