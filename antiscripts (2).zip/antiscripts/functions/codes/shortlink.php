<?php

// ──────────────────────────────────────────────────────────────────

/**
 * Resolve the final redirect URL from a shortlink page.
 */
function get_url_(string $slUrl, string $shortUrl, string $html, string $host, string $email, ?string $proxy = null): ?string {
    $formData     = extractFormData($html);

    $needsCaptcha = $formData['captcha_name'] || $formData['has_ukcap'] || strtolower($host) === 'feyorra.site';

    // Reload page if no captcha detected yet
    if (!$needsCaptcha) {
        $response     = Run($shortUrl, getRequestHeaders($host, parse_url("http://$proxy", PHP_URL_HOST), $email), 0, 'data', $proxy, 2, $email);
        $html         = $response['body'];
        $formData     = extractFormData($html);
        $needsCaptcha = $formData['captcha_name'] || $formData['has_ukcap'];
    }

    if ($needsCaptcha) {
        $payload = prepareFormPayload(
            $formData, $email, null, $shortUrl, $html, $host,
            $GLOBALS['apihost'] ?? null,
            $GLOBALS['apikey']  ?? null,
            null, $proxy
        );
        if (empty($payload)) return null;

        $actionUrl = strtolower($host) === 'feyorra.site'
            ? $shortUrl
            : ($formData['action_url'] ?? $shortUrl);

        $submit  = Run($actionUrl, getFormHeaders($host, $html, parse_url("http://$proxy", PHP_URL_HOST), $email), $payload, 'data', $proxy, 2, $email);
        $decoded = json_decode($submit['body'], true);

        if (is_array($decoded) && isset($decoded['url'])) return $decoded['url'];

        $redirect = extractRedirect($submit);
    } else {
        $response = $response ?? Run($shortUrl, getRequestHeaders($host, parse_url("http://$proxy", PHP_URL_HOST), $email), 0, 'data', $proxy, 2, $email);
        $redirect = extractRedirect($response);
    }

    // Ignore redirects that stay on the same host
    if ($redirect && str_contains($redirect, "https://$host")) return null;

    return $redirect ?: null;
}

// ──────────────────────────────────────────────────────────────────

/**
 * Extract redirect URL from response info or inline JS.
 */
function extractRedirect(array $response): ?string {
    $redirect = $response['info']['redirect_url'] ?? '';

    if (!$redirect && !empty($response['body'])) {
        if (preg_match('/location\.href\s*=\s*"([^"]+)"/i', $response['body'], $m)) {
            $redirect = $m[1];
        }
    }

    return $redirect ?: null;
}

// ──────────────────────────────────────────────────────────────────

/**
 * Claim all shortlinks for a given account.
 */
function claimShortlinks(array &$shortlinkUrls, string $host, array &$website, ?string $email = null, ?string $proxy = null): array {

    if (empty($shortlinkUrls)) return ['SL-LIMIT' => true];
  
    foreach ($shortlinkUrls as $slIndex => $slUrl) {
        // ── 1. Load shortlink page ────────────────────────────────
        $html      = safeRequest($slUrl, $host, $email, $proxy)['body'] ?? '';

        $shortInfos = extractUniversalShortlinks($html, "https://$host/");

        // ── 2. Offerwall fallback ─────────────────────────────────
        if (empty($shortInfos['shortlink'])) {
            if (!empty($shortInfos['offerwall']) && empty($website['offerwallLimit'])) {
                foreach ($shortInfos['offerwall'] as $link) {
                    $check = offerlinks($link['link'], $host, $email, $proxy);
                    if ($check && $check !== 'limit') return [];
                }
                return ['offerwall' => true];
            }
            continue;
        }

        // ── 3. Process each shortlink ─────────────────────────────
        foreach ($shortInfos['shortlink'] as $info) {
            $shortUrl = $info['link']      ?? '';
            $claimNow = $info['claim_now'] ?? 1;

            if (empty($shortUrl) || $claimNow <= 0) continue;

            $redirect = get_url_($slUrl, $shortUrl, $html, $host, $email, $proxy);
            if (!$redirect) continue;

            logMessage($host, "Shortlink: $redirect", 'SL', $proxy, CYAN);

            // ── 4. Bypass ─────────────────────────────────────────
            $bypass = bypass($redirect);
            if (empty($bypass['original_url'])) continue;

            countdown(rand(90, 130), '');

            // ── 5. Verify bypass ──────────────────────────────────
            $bypassResp = safeRequest($bypass['original_url'], $host, $email, $proxy);
            $verifyUrl  = $bypassResp['info']['redirect_url'] ?? '';
            if (!$verifyUrl) continue;

            safeRequest($verifyUrl, $host, $email, $proxy);

            // ── 6. Collect reward ─────────────────────────────────
            $finalHtml = safeRequest($slUrl, $host, $email, $proxy)['body'] ?? '';
            $reward    = extractRewardMessage($finalHtml);

            if (!$reward) {
                if ($host === 'feyorra.site') return [];
                continue;
            }

            if (str_contains($reward, 'The faucet does not have sufficient funds')) {
                logMessage($host, 'No funds → removing shortlink', 'SL', $proxy, RED);
                unset($shortlinkUrls[$slIndex]);
                $shortlinkUrls = array_values($shortlinkUrls);
                continue 2;
            }

            logMessage($host, $reward, 'SL', $proxy, GREEN);
            return [];
        }
    }

    return [];
}