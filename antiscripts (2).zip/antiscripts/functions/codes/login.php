<?php

// ──────────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────────

/**
 * Returns false if $url contains any forbidden keyword.
 */
function isValidRedirectUrl(string $url): bool {
    foreach (['auth', 'verify', 'post', 'login'] as $kw) {
        if (stripos($url, $kw) !== false) return false;
    }
    return true;
}

/**
 * Builds an absolute URL from a possibly-relative redirect.
 */
function resolveRedirect(string $redirect, string $host): string {
    return str_starts_with($redirect, '/')
        ? "https://{$host}{$redirect}"
        : $redirect;
}

// ──────────────────────────────────────────────────────────────────
// Already-logged-in check
// ──────────────────────────────────────────────────────────────────

/**
 * Inspects a response and returns a success result if the session
 * is already active, or ['success' => false] otherwise.
 */
function check_already_login(array $resp, string $host): array {
    $body     = $resp['body']                 ?? '';
    $redirect = $resp['info']['redirect_url'] ?? '';

    // Hard "not logged in" signal
    if (str_contains($body, 'Login / Register') || str_contains($body,'Forgot?')) {
        return ['success' => false];
    }

    // Follow a bare root redirect and re-check the body
    if ($redirect === "https://$host/") {
        $resp     = safeRequest($redirect, $host);
        $body     = $resp['body']                 ?? '';
        $redirect = $resp['info']['redirect_url'] ?? '';
    }

    // Redirect into a known logged-in area
    if ($redirect && isValidRedirectUrl($redirect)) {
        $resolved = resolveRedirect($redirect, $host);

        if (str_contains($resolved, 'dashboard') || str_contains($resolved, '/account')) {
            return ['success' => true, 'url' => $resolved, 'Message' => "Already logged in: $host"];
        }
    }

    // Body contains a logged-in marker
    $markers = ['logout', 'Logout', 'dashboard', 'Dashboard',
                "https://$host/dashboard", "https://$host/account"];

    foreach ($markers as $marker) {
        if (str_contains($body, $marker)) {
            return ['success' => true, 'url' => $resp['info']['url'] ?? '', 'Message' => "Already logged in: $host"];
        }
    }

    return ['success' => false];
}

// ──────────────────────────────────────────────────────────────────
// Login
// ──────────────────────────────────────────────────────────────────

/**
 * Logs in a single account and returns a result array:
 *   ['success' => bool, 'url' => string|null, 'Message' => string]
 */
function login(string $url, string $host, string $email, ?string $password = null, ?string $proxy = null): array {
    $fail = fn(string $msg) => ['success' => false, 'Message' => $msg];

    // ── 1. Fetch login page ───────────────────────────────────────
    $resp  = safeRequest($url, $host, $email, $proxy);

    $check = check_already_login($resp, $host);

    if ($check['success']) return $check;

    // ── 2. Parse & prepare the login form ────────────────────────
    $formData = extractFormData($resp['body']);


    if (!$formData) return $fail("No login form found: $host");

    $payload = prepareFormPayload(
        $formData, $email, $password, $url, $resp['body'], $host,
        $GLOBALS['apihost'] ?? null,
        $GLOBALS['apikey']  ?? null,
        null,
        $proxy
    );

    if (!$payload) return $fail("Could not build login payload: $host");

    // ── 3. Submit the form ────────────────────────────────────────
    $headers  = getFormHeaders($host, $resp['body'], parse_url("http://$proxy", PHP_URL_HOST));
    $actionUrl = $formData['action_url'] ?? $url;

    $verify = Run($actionUrl, $headers, $payload, 'data', $proxy, 2, $email);

    // ── 4. Re-check session after submit ─────────────────────────
    $check = check_already_login($verify, $host);
    if ($check['success']) return $check;

    // ── 5. Redirect to dashboard ──────────────────────────────────
    $redirect = $verify['info']['redirect_url'] ?? '';
    if ($redirect === "https://$host/dashboard" && isValidRedirectUrl($redirect)) {
        return ['success' => true, 'url' => $redirect, 'Message' => "Login successful: $host"];
    }

    // ── 6. JSON response ──────────────────────────────────────────
    $data = json_decode($verify['body'], true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($data)) {
        // URL returned directly
        $returnedUrl = $data['url'] ?? $data['data']['url'] ?? null;
        if ($returnedUrl && isValidRedirectUrl($returnedUrl)) {
            return ['success' => true, 'url' => $returnedUrl, 'Message' => "Login successful: $host"];
        }

        // status=success without URL → fall back to /dashboard
        if (($data['status'] ?? '') === 'success') {
            $dashboard = "https://$host/dashboard";
            if (isValidRedirectUrl($dashboard)) {
                return ['success' => true, 'url' => $dashboard, 'Message' => "Login successful: $host"];
            }
        }
    }

    return $fail("Login failed: $host");
}