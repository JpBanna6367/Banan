<?php
function Bypass($url){


    $data = json_encode([
        "apikey" => anticaptcha_key,
        "mode" => "shortlink",
        "url" => $url
    ]);

    $response = json_decode(Run(api_endpoint,["Content-Type: application/json"],$data)['body'],true);
    if(isset($response['jobId'])){
        $id = $response['jobId'];
       
        $data = json_encode([
            "apikey" => anticaptcha_key,
            "action" => "get",
            "id" => $id
        ]);

        $attempt = 0;
        $attempt_max = 20;
        while($attempt < $attempt_max){
            $response = json_decode(Run(api_endpoint,["Content-Type: application/json"],$data)['body'],true);
            if (isset($response["status"]) && $response["status"] === true) {
               return $response;
            }elseif($response['status'] == "pending"){
                sleep(5);
                $attempt += 1;
            }else{
               return $response;
            }
        }
    }
}

function earnow($link,$email = null,$proxy = null){
$parse = parse_url($link);
$host = $parse['host'];
if (!empty($parse['scheme']) && $parse['scheme'] === "http") {
    $link = preg_replace('/^http:/', 'https:', $link);
}
$body = safeRequest($link, $host, $email, $proxy);
$hd[] = "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7";
$hd[] = "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36";
$url = explode('";',explode('location.href = "', $body['body'])[1])[0];
if(empty($url))return ["message" => "Unable To get URL, Bypassed Failed!"];

$r = Run($url,$hd,null,"data",$proxy,2,$email);
$redirect = $r['info']['redirect_url'];
if(str_contains($redirect,'t.co')){
    
    $r = Run($redirect,$hd);
    $url = explode('</title>',explode('<title>',$r['body'])[1])[0];
   
    $r = Run($url,array_merge($hd,["referer: https://t.co/"]),null,"data",$proxy,2,$email);
    $redirect = $r['info']['redirect_url'];
   
    if(str_contains($redirect,'xpost')){
      
        $r = Run($redirect,array_merge($hd,["referer: https://t.co/"]),null,"data",$proxy,2,$email);   
    }
}
$redirect = $r['info']['redirect_url'];
$r = Run($redirect,$hd,null,"data",$proxy,2,$email);
$real = explode('"',explode('href="',$r['body'])[2])[0];

$r = Run($real,$hd,null,"data",$proxy,2,$email);
$redirect = $r['info']['redirect_url'];

$r = Run($redirect,$hd,null,"data",$proxy,2,$email);
$redirect = explode('">',explode('<a href="', $r['body'])[1])[0];


$head = ["content-type: application/json"];
$ref = "https://www.google.com/";
while(true){
    $r = Run($redirect,array_merge($hd,["referer: $ref"]),null,"data",$proxy,2,$email);
    if($r['info']['redirect_url']){
        $redirect = $r['info']['redirect_url'];
        $r = Run($r['info']['redirect_url'],array_merge($hd,["referer: $ref"]),null,"data",$proxy,2,$email);
   }
    $ref = $redirect;
    $ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36";
    $redirect_host = parse_url($redirect)['host'];
    $html = $r['body'];
    $step = explode('</span>',explode('<span>Step ',$r['body'])[1])[0];
    animation($step);
   if(empty($step))return ["message" => "No Step Found"];
    $value = explode('" value="true"',explode('<input type="hidden" name="',$r['body'])[1])[0];
    $sitekey = explode('"',explode('site-key="',$r['body'])[1])[0];

    $sl = explode('.js"', explode('<script src="/sl/', $html)[1])[0];
    if(empty($sl))continue;
    $js_headers = [
        "user-agent: $ua",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "accept-language: en-US,en;q=0.9",
        "referer: $redirect",
        "origin: https://$redirect_host",
        "sec-fetch-dest: script",
        "sec-fetch-mode: no-cors",
        "sec-fetch-site: same-origin",
        'sec-ch-ua: "Not(A:Brand";v="8", "Chromium";v="144", "Android WebView";v="144"',
        "sec-ch-ua-mobile: ?1",
        'sec-ch-ua-platform: "Android"',
        "connection: keep-alive",
        "cache-control: no-cache",
        "pragma: no-cache"
    ];

    $js_url = "https://$redirect_host/sl/$sl.js";
   
    $js = Run($js_url, $js_headers, null, "data", $proxy, 2, $email)['body'];
    if ($js == "$sl.js") {
        continue;
    }

    // 7. Parse JS – names, validation key, hash
    preg_match('/JSON\.stringify\(\{\s*\'([^\']+)\'\s*:\s*[^,]+,\s*\'([^\']+)\'/', $js, $m);
    $name1 = $m[1] ?? null;
    $name2 = $m[2] ?? null;
    // uk – only present in some JS files
    $uk = null;
    $value_hash = null;

    if (strpos($js, "'?") !== false && strpos($js, "=true';") !== false) {
        $uk = explode("=true';", explode("'?", $js)[1])[0];
    }

    $value_hash = explode("'",explode("': '",$js)[2])[0];

    $i = 0;
    while (empty($value_hash)) {
        $value_hash = explode("'", explode("'", $js)[$i] ?? '')[0] ?? null;
        if ($value_hash &&
            strpos($value_hash, "\n") === false &&
            strpos($value_hash, "\r") === false &&
            preg_match('/^[a-f0-9]{64}$/i', $value_hash)) {
            break;
        }
        $value_hash = null;
        $i++;
    }

      // 9. Validation request (fingerprint POST) – skipped if $uk missing
      if ($uk) {
        $validation_url = $redirect . "?$uk=true";
       
        $fp_output = [
            $name1 => finger_print($ua),
            $name2 => $value_hash ?? '6c3d03b6a4135c8a3c5ac75a5e02784a9dfda77114731be3c2ae596ea8b6f098'
        ];

        $val_headers = [
            "User-Agent: $ua",
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language: en-GB,en-US;q=0.9,en;q=0.8",
            "Upgrade-Insecure-Requests: 1",
            "X-Requested-With: XMLHttpRequest",
            "Origin: https://$redirect_host",
            'sec-ch-ua: "Not(A:Brand";v="8", "Chromium";v="144", "Android WebView";v="144"',
            "sec-ch-ua-mobile: ?1",
            'sec-ch-ua-platform: "Android"',
            "sec-fetch-dest: document",
            "sec-fetch-mode: navigate",
            "sec-fetch-site: same-origin",
            "sec-fetch-user: ?1",
            "Connection: keep-alive"
        ];

        $req = json_encode($fp_output, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        $js2 = json_decode(Run($validation_url, $val_headers, $req, "data", $proxy, 2, $email)['body'], true);
        if ($js2['status'] == 403) {
            continue;
        }
    }

    $cap = SolveHhCaptcha($sitekey,$redirect,$head);
    $solve = $cap['token'] ?? null;
    $data = http_build_query([
        "h-captcha-response" => $solve,
        "g-recaptcha-response" => $solve,
        "h-captcha-response" => $solve,
        $value => "true"
    ]);
    $post_hd = [
        "content-type: application/x-www-form-urlencoded",
        "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-language: en-US,en;q=0.9",
        "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
        "referer: $redirect",
    ];
    $ho = array_merge($hd,["referer: $redirect"]);
    $r = Run($redirect, $post_hd, $data, "data", $proxy, 2, $email);
    $redirect = $r['info']['redirect_url'];
    if($redirect){
        if(str_contains($redirect,"t.co")){
            $r = Run($redirect,$hd);
            $url = explode('</title>',explode('<title>',$r['body'])[1])[0];
            $r = Run($url,array_merge($hd,["referer: https://t.co/"]));
            $redirect = $r['info']['redirect_url'];
            if(str_contains($redirect,'xpost')){
                $r = Run($redirect,array_merge($hd,["referer: https://t.co/"]));   
            }
            continue;    
        }else{
        return ["original_url" => $redirect,"message" => "Bypass Success"];
    }
}
    $re = explode('";',explode('location.href = "', $r['body'])[1])[0];
    $r = Run($re,$ho);
    $redirect = $r['info']['redirect_url'];
    if(str_contains($redirect,'t.co')){
        $r = Run($redirect,$hd);
        $url = explode('</title>',explode('<title>',$r['body'])[1])[0];
        $r = Run($url,array_merge($hd,["referer: https://t.co/"]));
        $redirect = $r['info']['redirect_url'];
        if(str_contains($redirect,'xpost')){
            $r = Run($redirect,array_merge($hd,["referer: https://t.co/"]));   
        }
    }
    $redirect = $r['info']['redirect_url'];
    }
}



function SolveHhCaptcha($siteKey, $domain,$head, $sleep = 5, $maxTries = 24) {
    // Create job
    $create = ApiPost($head, [
        "apikey" => anticaptcha_key,
        "mode" => "hcaptcha",
        "domain" => $domain,
        "siteKey" => $siteKey,
    ]);

    if (empty($create['jobId'])) {
        return [
            "success" => false,
            "message" => "Failed to create captcha job",
            "response" => $create
        ];
    }

    $jobId = $create['jobId'];

    // Poll for result
    for ($i = 1; $i <= $maxTries; $i++) {
        $check = ApiPost($head, [
            "apikey" => anticaptcha_key,
            "action" => "get",
            "id" => $jobId
        ]);

        if (!empty($check['token'])) {
            return [
                "success" => true,
                "jobId" => $jobId,
                "token" => $check['token'],
                "raw" => $check
            ];
        }

        if (($check['status'] ?? null) === "pending") {
            sleep($sleep);
            continue;
        }

        return [
            "success" => false,
            "message" => "Unexpected API response",
            "jobId" => $jobId,
            "response" => $check
        ];
    }

    return [
        "success" => false,
        "message" => "Captcha timeout",
        "jobId" => $jobId
    ];
}

function ApiPost($head, $data, $proxy = null, $email = null) {
    $res = Run(api_endpoint, $head, json_encode($data), "data", $proxy, 2, $email);
    return json_decode($res['body'] ?? '', true);
}


function finger_print($ua) {
    return [
        'userAgent' => 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36',
        'platform' => 'Linux armv81',
        'language' => 'en-US',
        'timezoneOffset' => -300,
        'canvas' => 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAALV0lEQVR4AeybZ8gsRRaGe5dlc/qxC8smVAxgzgEDimAWxIwBzJjFgIqKioo5B0REBRNmUTBizhFzTqhgRBRz1vcd7Mvcud/M9HSYrqp+5Jyp6u7q6lPP8Xupqu7764z/IAABCERCAMGKJFGECQEIZNmgYP0OUA6VPyB/Qn6UPCY7XMHuKccgAIEECQwK1oYa4/byE+W7yB+Rx2Q3Kti75EVsVTV6XV7EJmk7rr+/qcFP8nnlUzUeBoHYCQwK1lwa0NXya+QPya+Xx2QW2KdjCphYIQCB4gT6BesK3Xa0fG+5ZwD/U+nl4XEqbcvq5yX5xvL75M/Jd5T321Y6sGi4nZdmV+p4A7ntV/rZRH6d/A358fI/y23u+01VdpK79PFeql8iP0nu9veqXEee2+6qnCc/Wf6J/Lfy0+QHyW2+fpYqB8gdz20qV5Db3O5OVeaWe6wrqRxmw9r+Wzd4yfyqSs/sPAtTtWd/0O/B8uflXl6bk8e/mY4dq4rsFf3sK8cgAIGCBPoFa1Pdc5jcQuI/rrdVH7T5dcJ/qBaOPVQ/Qb683ObyIlUsfNuq9B+txU3Vnm2p363l/kNeTuV/5AfKc/u/KgvLN5e/ILetrh8L3EIqT5HfIO9fSm2nY4uZ232n+qDtqhOPyZeRe9bovv6qusVwNZW+12O1AOtwRpuprYXWsbysO5aWnyG/VW42KjKLvse4tg7MaTeV5nu5yr/LbfPpx2KsAoNAzQQS7a5fsIoM8Ws1OlP+qfwO+U3yBeW2jfRzttz7X55VeGb2qI5z208Vi+GzKj+QHyn3LCiPwX3vo3MPyj+T2ywK96jypdyC4xmbxVKHPfMMzGLxuI48U1Ixm12so9vljvcclf+Ue9mropJZIC3oF6oXz5jMwbO9tXRss/BaHD1bdGzeD3zPF3AIQKA8gVwsivbwoxraVfTMQvLHXi3L5lH5sLzfLEI+9oxkMVW8rLOw2D2L8gb0v3Te5n6/d2WEP6Vr/5Xn9k1eGVJ+23f+B9Ud7+9VVjXP8tZXJx5H7jvr2AxUZBbRY1Q5Ve5Zpjf371YdgwAEKhCYVLBGPcqCMOq6r/kt5BKq9PtHOi5q/uzCAlG0fZPtrlLn/eNw/Vyds3mWuIgqXmp6b8tCu6SOMQhAoAKBOgXLG8zeK8rD8d6Q97F8/Ll+fP0vKp/sc+8BjZolDc6GvO/kTW510aCN7/o1NfG+mjfz8/F4E91LwN/omjfZLeAWNS97j9U5fy6iAoMABMoSqFOwvGfjzWVvOK+ogLyH5Q1pVXvmJZL3uLxR7r0kb4j7E4rexSE/W+i823npuIPqfpt3s8o6zPtk/1BHS8nzjXBVZ7TBtreolQXpMpV+EWGh9lhW0bGXtZ5JHqG6l4gWtjVVf1du+0I/fkHg5/Yvb3UagwAERhGoU7D8Zbw/a7DIeGnkWcj9erj3plRkl+rHsw2/QfSSyW/JvO+j00PNm+p+q+dZzDZqtZ7cm90qKtsz6uF0uUXHe1KqDrXBtl+p5bryd+V++eAv7P2G1Ht0OpV5jJ5VejPeLxk+1kl/YqEis6BZfP1Gdg2fwCEAgWIEBgXLswJ/t5Tf3X/s76v+lF/4pfQyx28NfznMrlXFsw2/OfRbM88w/EZQpzML1wWqrCy3QHgm5iWUDrOZ+vZ5Lxe9nPL3Up5d+a2hz9v9XD/f9dz9CYK/JfPxTNcdv5/l696QP0QVC6fFxXHO5F6W9rf1ZxK6LXtLP/5uzLMki5fFNd9f8xvB/XV9AbmHxhZxi5YOe+a3i2Z0fu+InxYJ8OiYCAwKVpXYF9XN/pzBguSllr/R8vLHe1e6FLS9qOgWH+L5m05dxiAAgTYJ1ClY3kD3P+Xx7OFDDcr7Nv5Y0t9A6TB4e0cRzuQ6jUEAAiEQqFOwPBPxP+Xx8s3LIC95vK9Vdpz+JzGDS76yfXEfBCCQAIGKgpUAAYYAAQhEQwDBiiZFBAoBCCBY/D8AAQhEQwDBiiZVrQdKABBonQCC1XoKCAACEChKAMEqSop2EIBA6wQQrNZTQAAQCI9AqBEhWKFmhrggAIE5CCBYcyDhBAQgECoBBCvUzBAXBCAwBwEEaw4k1U/QAwQg0AwBBKsZrvQKAQg0QADBagAqXUIAAs0QQLCa4UqvXSHAOKdKAMGaKm4eBgEIVCGAYFWhx70QgMBUCSBYU8XNwyAAgSoE2hWsKpFzLwQg0DkCCFbnUs6AIRAvAQQr3twROQQ6RwDB6lzK2xowz4VAdQIIVnWG9AABCEyJAII1JdA8BgIQqE4AwarOkB4gAIHZCTR2hGA1hpaOIQCBugkgWHUTpT8IQKAxAghWY2jpGAIQqJsAglU30er90QMEIDCEAII1BAynIQCB8AggWOHlhIggAIEhBBCsIWA4DYFpEOAZkxFAsCbjRWsIQKBFAghWi/B5NAQgMBkBBGsyXrSGAARaJBC1YLXIjUdDAAItEECwWoDOIyEAgXIEEKxy3LgLAhBogQCC1QJ0HlmCALdAQAQQLEHAIACBOAggWHHkiSgiAAERQLAEAYMABEIiMDwWBGs4G65AAAKBEUCwAksI4UAAAsMJIFjD2XAFAhAIjACCFVhCqodDDxBIlwCClW5uGRkEkiOAYCWXUgYEgXQJIFjp5paRpU+gcyNEsDqXcgYMgXgJIFjx5o7IIdA5AghW51LOgCEQL4EuC1a8WSNyCHSUAILV0cQzbAjESADBijFrxAyBjhJAsDqa+K4Nm/GmQQDBSiOPjAICnSCAYHUizQwSAmkQQLDSyCOjgEAnCBQSrE6QYJAQgEDwBBCs4FNEgBCAQE4AwcpJUEIAAsETQLCCT9GUA+RxEAiYAIIVcHIIDQIQmJ0AgjU7D44gAIGACSBYASeH0CDQLIH4ekew4ssZEUOgswQQrM6mnoFDID4CCFZ8OSNiCHSWAIJVOvXcCAEITJsAgjVt4jwPAhAoTQDBKo2OGyEAgWkTQLCmTZznxUiAmAMhgGAFkgjCgAAExhNAsMYzogUEIBAIAQQrkEQQBgQgMJ7ANARrfBS0gAAEIFCAAIJVABJNIACBMAggWGHkgSggAIECBBCsApBoUpwALSHQJAEEq0m69A0BCNRKAMGqFSedQQACTRJAsJqkS98QSJlAC2NDsFqAziMhAIFyBBCscty4CwIQaIEAgtUCdB4JAQiUI4BgleNW/S56gAAEJiaAYE2MjBsgAIG2CCBYbZHnuRCAwMQEEKyJkXEDBCYlQPu6CCBYdZGkHwhAoHECCFbjiHkABCBQFwEEqy6S9AMBCDROIALBapwBD4AABCIhgGBFkijChAAEsgzB4v8CCEAgGgIIVjSp6kSgDBICIwkgWCPxcBECEAiJAIIVUjaIBQIQGEkAwRqJh4sQgEBTBMr0i2CVocY9EIBAKwQQrFaw81AIQKAMAQSrDDXugQAEWiGAYLWCvfpD6QECXSSAYHUx64wZApESQLASTRxhQ6CLBBCsLmadMcdFgGhnEUCwZqGgAgEIhE4AwQo9Q8QHAQjMIoBgzUJBBQIQCJ1A+oIVegaIDwIQKEwAwSqMioYQgEDbBBCstjPA8yEAgcIEEKzCqGgYPgEiTJ0AgpV6hhkfBBIigGAllEyGAoHUCSBYqWeY8UEgIQJ9gpXQqBgKBCCQJAEEK8m0MigIpEkAwUozr4wKAkkSQLCSTOvYQdEAAlESQLCiTBtBQ6CbBBCsbuadUUMgSgIIVpRpI2gIFCeQUksEK6VsMhYIJE4AwUo8wQwPAikRQLBSyiZjgUDiBBCsMQnmMgQgEA4BBCucXBAJBCAwhgCCNQYQlyEAgXAIIFjh5IJI2ibA84MngGAFnyIChAAEcgIIVk6CEgIQCJ4AghV8iggQAhDICfwMAAD//wvTxNMAAAAGSURBVAMATFgLPMmUVq8AAAAASUVORK5CYII=',
        'webgl' => [
            'vendor' => 'ARM',
            'renderer' => 'Mali-G57'
        ],
        'audio' => '18614.610422088925',
        'deviceMemory' => 4,
        'hardwareConcurrency' => 8
    ];
}