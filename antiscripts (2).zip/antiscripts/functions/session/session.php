<?php
/**
 * SessionManager.php
 * Handles persistent storage of login sessions and cached links per host.
 */

class SessionManager {
    private static $instance = null;
    private $dataFile;
    private $data = [];

    private function __construct() {
        $baseDir = getenv('BSE_DIR') ?: dirname(__DIR__) . '/BSE_DIR';
        $sessionsDir = $baseDir . '/sessions';
        if (!is_dir($sessionsDir)) {
            mkdir($sessionsDir, 0777, true);
        }
        $this->dataFile = $sessionsDir . '/host-data.json';
        $this->load();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function load() {
        if (file_exists($this->dataFile)) {
            $content = file_get_contents($this->dataFile);
            $this->data = json_decode($content, true) ?: [];
        } else {
            $this->data = [];
            $this->save();
        }
    }

    private function save() {
        file_put_contents($this->dataFile, json_encode($this->data, JSON_PRETTY_PRINT));
    }

    /**
     * Ensure a host entry exists in the data array.
     */
    private function initHost($host) {
        if (!isset($this->data[$host])) {
            $this->data[$host] = [
                'faucet_urls'      => [],
                'shortlink_urls'   => [],
                'ptc_urls'         => [],
                'offerwall_urls'   => [],
                'last_fetched'     => 0,
                'login_sessions'   => []
            ];
        }
    }

    /**
     * Check if a login session is valid (within 15 minutes).
     */
    public function isLoginValid($host, $email) {
        $this->initHost($host);
        $sessions = &$this->data[$host]['login_sessions'];
        if (!isset($sessions[$email])) return false;
        $expires = $sessions[$email]['expires'] ?? 0;
        return time() < $expires;
    }

    /**
     * Save a successful login session (valid for 15 minutes).
     */
    public function saveLogin($host, $email, $password = '', $proxy = null) {
        $this->initHost($host);
        $this->data[$host]['login_sessions'][$email] = [
            'expires'   => time() + 900, // 15 minutes
            'password'  => $password,
            'proxy'     => $proxy
        ];
        $this->save();
    }

    /**
     * Get cached login data (if still valid).
     */
    public function getLoginData($host, $email) {
        $this->initHost($host);
        return $this->data[$host]['login_sessions'][$email] ?? null;
    }

    /**
     * Fetch and cache faucet, shortlink, PTC & offerwall URLs.
     * If cached within 3 hours, return cached; else call $fetchCallback.
     */
    public function getLinks($host, callable $fetchCallback) {
        $this->initHost($host);
        $last = $this->data[$host]['last_fetched'] ?? 0;
        $threeHours = 3 * 3600;

        if (time() - $last < $threeHours && !empty($this->data[$host]['faucet_urls'])) {
            return [
                'faucet'     => $this->data[$host]['faucet_urls'],
                'shortlinks' => $this->data[$host]['shortlink_urls'],
                'ptc'        => $this->data[$host]['ptc_urls'],
                'offerwall'  => $this->data[$host]['offerwall_urls']
            ];
        }

        // Fetch fresh links
        $links = $fetchCallback();
        $this->data[$host]['faucet_urls']    = $links['faucet'] ?? [];
        $this->data[$host]['shortlink_urls'] = $links['shortlinks'] ?? [];
        $this->data[$host]['ptc_urls']       = $links['ptc'] ?? [];
        $this->data[$host]['offerwall_urls'] = $links['offerwall'] ?? [];
        $this->data[$host]['last_fetched']   = time();
        $this->save();

        return $links;
    }

    /**
     * Remove a specific faucet URL (and its matching shortlink URL) from the cache.
     */
    public function removeFaucetUrl($host, $faucetUrl) {
        $this->initHost($host);

        // Remove from faucet list
        $faucetList = &$this->data[$host]['faucet_urls'];
        $index = array_search($faucetUrl, $faucetList);
        if ($index !== false) {
            unset($faucetList[$index]);
            $faucetList = array_values($faucetList);
        }

        // Derive corresponding shortlink URL and remove it
        $shortlinkUrl = str_replace('/faucet/', '/links/', $faucetUrl);
        $shortList = &$this->data[$host]['shortlink_urls'];
        $index2 = array_search($shortlinkUrl, $shortList);
        if ($index2 !== false) {
            unset($shortList[$index2]);
            $shortList = array_values($shortList);
        }

        $this->save();
    }

    /**
     * Remove a specific PTC URL from the cache.
     */
    public function removePtcUrl($host, $ptcUrl) {
        $this->initHost($host);
        
        $ptcList = &$this->data[$host]['ptc_urls'];
        $index = array_search($ptcUrl, $ptcList);
        if ($index !== false) {
            unset($ptcList[$index]);
            $ptcList = array_values($ptcList);
        }
        
        $this->save();
    }

    /**
     * Remove a specific offerwall URL from the cache.
     */
    public function removeOfferwallUrl($host, $offerwallUrl) {
        $this->initHost($host);
        
        $offerwallList = &$this->data[$host]['offerwall_urls'];
        $index = array_search($offerwallUrl, $offerwallList);
        if ($index !== false) {
            unset($offerwallList[$index]);
            $offerwallList = array_values($offerwallList);
        }
        
        $this->save();
    }

    /**
     * Force refresh links on next request.
     */
    public function expireLinks($host) {
        $this->initHost($host);
        $this->data[$host]['last_fetched'] = 0;
        $this->save();
    }

    /**
     * Get all cached links for a host (for debugging/admin).
     */
    public function getAllCachedLinks($host) {
        $this->initHost($host);
        return [
            'faucet'     => $this->data[$host]['faucet_urls'],
            'shortlinks' => $this->data[$host]['shortlink_urls'],
            'ptc'        => $this->data[$host]['ptc_urls'],
            'offerwall'  => $this->data[$host]['offerwall_urls'],
            'last_fetched' => $this->data[$host]['last_fetched']
        ];
    }

    /**
     * CLI interactive prompt to manually add/update host data.
     */
    public function askForSessionData() {
        if (PHP_SAPI !== 'cli') {
            throw new RuntimeException('CLI only.');
        }

        echo "=== Session Data Entry ===\n";
        $host   = readline("Host (e.g., claimcrypto.cc): ");
        $email  = readline("Email (optional, press Enter to skip): ");
        $action = readline("Action (e.g., faucet, login, ptc, offerwall): ");
        $data   = readline("Data (JSON string or plain text): ");

        $email = trim($email) ?: null;

        return [
            'host'   => trim($host),
            'email'  => $email,
            'action' => trim($action),
            'data'   => trim($data)
        ];
    }
}




