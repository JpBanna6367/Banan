<?php


function captcha($url,$sitekey,$method){
    $json = json_encode([
    "apikey" => anticaptcha_key,
    "mode" => $method,
    "domain" => $url,
    "siteKey" => $sitekey
    ]);

    $r = json_decode(Run(api_endpoint,["Content-Type: application/json"],$json)['body'],true);

    if(isset($r['jobId'])){
        return poll($r['jobId']);
    }
}

function poll($id){
    $maxTries = 12;
    for ($i = 1; $i <= $maxTries; $i++) {
    $json = json_encode(["apikey" => anticaptcha_key,"action" => "get","id" => $id]);
    $r = json_decode(Run(api_endpoint,["Content-Type: application/json"],$json)['body'],true);
    if (isset($r["status"]) && $r["status"] === true) {
        return $r;
     }elseif($r['status'] == "pending"){
         #animation("Getting Captcha...");
         sleep(10);
     }else{
        return $r;
     }
    }
}

function get_balance(){
    $data = json_encode([
        "apikey" => anticaptcha_key,
        "action" => "getbalance"
    ]);

    $r = json_decode(Run(api_endpoint, ["Content-Type: application/json"],$data)['body'],true);
    if(isset($r['balance'])){
        return $r['balance'];
    }else{
        echo RED . "Unable To fetch Balance Report this ASAP to the admin: \n";
        print_r($r);
        null;
    }
}