<?php


include_once(__DIR__ . "/anticaptcha/anti_captcha.php");
include_once(__DIR__ . "/antibot/antibot_connector.php");
include_once(__DIR__ . "/cloudflare/cf.php");
include_once(__DIR__ . "/rscaptcha/rsconnecter.php");

