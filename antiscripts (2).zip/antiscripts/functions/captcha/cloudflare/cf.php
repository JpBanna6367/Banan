<?php
function bypassCloudFlare($url_, $proxy = null) {
    $host = parse_url($url_, PHP_URL_HOST);
    $baseDir = BASE_DIR . "/configs/{$host}-config/";

    // Ensure config directory exists
    if (!is_dir($baseDir)) {
        mkdir($baseDir, 0755, true);
    }

    // ------------------------------------------------------------
    // CASE 1: NO PROXY – use localhost service
    // ------------------------------------------------------------
    if (empty($proxy)) {
        $url = 'http://localhost:7860/bypass';

        $data = [
            'mode'   => 'iuam',
            'domain' => $url_,
        ];

        $jsonData = json_encode($data);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ["success" => false, "error" => "cURL Error (local): $error"];
        }
        if ($httpCode !== 200) {
            return ["success" => false, "error" => "HTTP Error (local): $httpCode, Response: $response"];
        }

        $resp = json_decode($response, true);
        $cloudflare_cookie = $resp['cf_clearance'] ?? null;
        $user_agent        = $resp['user_agent']   ?? '';

        if ($cloudflare_cookie) {
            // Save cookie (no proxy, so use generic filename)
            file_put_contents($baseDir . "cf_cookie.txt", "cf_clearance " . $cloudflare_cookie);
            file_put_contents($baseDir . "userAgent", $user_agent);

            return [
                "cloudflare_cookie" => $cloudflare_cookie,
                "user_agent"        => $user_agent,
                "success"           => true,
            ];
        }

        return [
            "cloudflare_cookie" => null,
            "user_agent"        => $user_agent,
            "success"           => false,
        ];
    }

    // ------------------------------------------------------------
    // CASE 2: PROXY PROVIDED – use captcha API
    // ------------------------------------------------------------
    $proxyHost = null;

    // Prepare API payload
    $payload = [
        'apikey' => anticaptcha_key,   // must be defined globally
        'mode'   => 'iuam',
        'domain' => $url_
    ];

    // Normalise proxy string
    if (!preg_match('#^https?://#i', $proxy)) {
        $proxy = "http://{$proxy}";
    }
    $parts = parse_url($proxy);

    if (!empty($parts['host'])) {
        $proxyData = [
            'hostname' => $parts['host'],
            'port'     => $parts['port'] ?? ($parts['scheme'] === 'https' ? 443 : 80),
            'scheme'   => $parts['scheme'] ?? 'http'
        ];
        $proxyHost = $parts['host'];
        $proxyPort = $parts['port'];

        if (!empty($parts['user']) && !empty($parts['pass'])) {
            $proxyData['username'] = $parts['user'];
            $proxyData['password'] = $parts['pass'];
        }

        $payload['proxy'] = $proxyData;
    }

    // Submit task to API
    $jsonPayload = json_encode($payload);
    $ch = curl_init(api_endpoint);   // must be defined globally
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error    = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ["success" => false, "error" => "cURL Error (API submit): $error"];
    }
    if ($httpCode !== 200) {
        return ["success" => false, "error" => "HTTP Error (API submit): $httpCode, Response: $response"];
    }

    $submitResult = json_decode($response, true);
    

    // Check for immediate API errors
    if (isset($submitResult['error'])) {
        if (stripos($submitResult['error'], 'Insufficient balance') !== false) {
            exit("ERROR: No API balance available. Please top up your captcha service account.\n");
        }
        return ["success" => false, "error" => $submitResult['error']];
    }

    if (empty($submitResult['jobId'])) {
        return ["success" => false, "error" => "No jobId received from API"];
    }

    $jobId = $submitResult['jobId'];
    $pollResult = poll($jobId);
     

        // Success – extract cf_clearance and user_agent
        $cloudflare_cookie = $pollResult['cookie'] ?? null;
        $user_agent        = $pollResult['user_agent']   ??  $pollResult['UserAgent']   ??  $pollResult['Useragent']   ??  $pollResult['userAgent'] ?? null;

        if ($cloudflare_cookie) {
            // Save cookie with proxy‑specific filename
            $cookieFilename = empty($proxyHost) ? "cf_cookie.txt" : "{$proxyHost}-{$proxyPort}-cf_cookies.txt";
            file_put_contents($baseDir . $cookieFilename, "cf_clearance " . $cloudflare_cookie);
            file_put_contents($baseDir . "userAgent", $user_agent);

            return [
                "cloudflare_cookie" => $cloudflare_cookie,
                "user_agent"        => $user_agent,
                "success"           => true,
            ];
        }

        // If we got here, the API returned an unexpected format
        return [
            "cloudflare_cookie" => null,
            "user_agent"        => $user_agent,
            "success"           => false,
            "error"             => "API did not return cf_clearance"
        ];
    }
