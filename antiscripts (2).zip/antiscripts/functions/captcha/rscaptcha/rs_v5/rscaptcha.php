<?php

function rsv5($app_id,$public_key){
    $payload = [
        'apikey'       => anticaptcha_key,
        'mode'         => 'rsv5',
        'appId' => $app_id,
        'publicKey' => $public_key
    ];
    
    
    $response = json_decode(Run(api_endpoint, ['Content-Type: application/json'], json_encode($payload))['body'], true);
    if (empty($response['jobId'])) return null;

    return poll($response['jobId']);
}
function rs($html,$ua){
$app_id = trim(explode('&', explode('app_id=', $html)[1])[0]);
$public_key = trim(explode('&', explode('public_key=', $html)[1])[0]);
    
  
    $data = rsv5($app_id,$public_key);
if($data['captcha_key']){
    return [
        "rs-id" => $data['captcha_key'],
        "rs-token" => $data['token'],
    ];
}else{
    return [
        "rs-id" => null,
        "rs-token" => null,
    ];
}
}

?>