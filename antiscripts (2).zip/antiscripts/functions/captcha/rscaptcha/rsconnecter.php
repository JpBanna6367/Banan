<?php

$base = __DIR__;

include_once($base . "/rs_v5/rscaptcha.php");
include_once($base . "/rs_upsidedown/rs_upsidedown.php");
