<?php
include(__DIR__ . "/rss.php");

function rs_upsidedown(string $html, string $url): array {
    // 1. Fetch captcha image
    $imageBytes = (new RsCaptchaImage())->fetch($html, $url);
    if (!$imageBytes) return ['rs-response' => null];

    // 2. Get click coordinates from API
    $coords = rs_cords($imageBytes);

    if (empty($coords['x']) || empty($coords['y'])) return ['rs-response' => null];

    // 3. Build token
    $token = (new RsCaptchaBuilder())->build((int)$coords['x'], (int)$coords['y'], $html);
    
    return ['rs-response' => $token];
}

function rs_cords(string $imageBytes): ?array {
    $payload = json_encode([
        'apikey'       => anticaptcha_key,
        'mode'         => 'rsv2',
        'image_base64' => base64_encode($imageBytes),
    ]);

    $response = json_decode(Run(api_endpoint, ['Content-Type: application/json'], $payload)['body'], true);

    if (empty($response['jobId'])) return null;

    return poll($response['jobId']);
}